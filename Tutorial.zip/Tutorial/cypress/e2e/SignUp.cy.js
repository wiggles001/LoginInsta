const butSignup = '#spark-app > main > div > div.card-body.form > form > div:nth-child(8) > a'
const signupFN = '[id = "first-name-field"]'
const singupLN = '[id = "last-name-field"]'
const phoneNm = '[id  = "phone-field"]'
const emailField = '[id = "email-field]'
const passwordField = '[id = "password-field"]'
const passwordCF = '[id = password-confirm-field]'
const TermsCond  = '#spark-app > main > div > div.spark-screen.spark_grid > div:nth-child(1) > div.card-body.form > form > div:nth-child(1) > div:nth-child(7) > div > div > div.flex.justify_start > label'

 //Random int number generator between min and max
 function getRandomInt(min, max){      
  return Math.floor(Math.random() * (max - min + 1)) + min;    
} 

describe('Sign UP', () => {
    it('Login', () => {
      cy.visit('https://stg.apicenter.io')
    })
    it('Go to SignUp',() => {
      cy.get(butSignup).click().should('be.visible')
    })
    it('Input Fistname', () => {
      cy.get(signupFN).type('Herbert')
    })
    it('Input Lastname', () => {
      cy.get(singupLN).type('Tester')
    })
    it('Input Phone field', () => {
      cy.get(phoneNm).type('Herbert')
    })
    it('Input Email', () => {
      cy.get(emailField).type('herbert001@gmail.com')
    })
    it('Input Password', () => {
      cy.get(passwordField).type('Herbert')
    })
    it('Input Confirm Password', () => {
      cy.get(passwordCF).type('Herbert')
    })
    it()
    it('Terms and Condition', () => {
      cy.get(TermsCond).click()
    })
    

  })