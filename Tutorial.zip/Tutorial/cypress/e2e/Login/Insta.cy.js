const butSubmit = '#loginForm > div > div:nth-child(3)'
const email = 'input[type = "text"]'
const password = 'input[type="password"]'
const submitbut = 'button[type = "submit"]'
const errorSelectorLogIn = '#slfErrorAlert'
describe('Login spec', () => { 
    beforeEach(() =>{
    cy.visit('https://www.instagram.com/')
    })
    it('Input wrong creds', () => {
      cy.get(email).type('Sample@gmail.com')
      cy.get(password).type('kahskjhasj')
      cy.get(submitbut).should('be.enabled').click()
      cy.get(errorSelectorLogIn).should('contain','Sorry, your password was incorrect. Please double-check your password.')
    })


    it('input email', () => {
      cy.get(email).type('jursuajrii@gmail.com')
      cy.get(submitbut).should('be.disabled')
      cy.get(password).type('jordison01')
      cy.get(submitbut).should('be.enabled').click()
    })
    // it('input Email and Password'), () => {
    //     cy.get(email).type('jursuajrii@gmail.com')
    //     cy.get(password).type('jordison01')
    // }
 


})
