const email = '[id = "email-field"]';
const password = ' [id = "password-field"]';
const signIn = ' [value = "Sign in"]';
const websiteApiStg = 'https://stg.apicenter.io/';
npx
describe('Login spec', () => {
    it('Visit APIcenter', () => {
      cy.visit(websiteApiStg)
      //cy.visit('/', {failOnStatusCode: false});
    })
    it('Email input',() => {
      cy.get(email).type ('herbertbelbes@gmail.com') //inpput email
    })
    it('Password input',() => {
        cy.get(password).type ('Qazwsx123!@#')
    })
    it('Click sign in Button', ()=> {
        cy.get(signIn).should('not.be.disabled').click()
   })

  })

